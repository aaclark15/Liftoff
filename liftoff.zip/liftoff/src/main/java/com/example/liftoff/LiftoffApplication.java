package com.example.liftoff;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiftoffApplication {

	public static void main(String[] args) {
		SpringApplication.run(LiftoffApplication.class, args);
	}

}
